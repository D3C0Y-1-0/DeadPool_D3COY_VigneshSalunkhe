with open("endpoint-agent/mirage_agent/config.py", "r", encoding="utf-8") as f:
    text = f.read()

text = text.replace("poll_interval_seconds: int = 15", "poll_interval_seconds: int = 2")
text = text.replace('"poll_interval_seconds", 15', '"poll_interval_seconds", 2')

with open("endpoint-agent/mirage_agent/config.py", "w", encoding="utf-8") as f:
    f.write(text)

print("Updated config.py poll_interval to 2s!")
